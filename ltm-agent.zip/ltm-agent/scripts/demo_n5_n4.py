"""Demo kịch bản mentor quan tâm: trình độ N5 -> người dùng báo N4 -> bộ nhớ phải đổi.

Chạy offline (không cần API key):
    LTM_LLM_PROVIDER=mock python scripts/demo_n5_n4.py

Chạy thật với OpenAI:
    OPENAI_API_KEY=sk-... python scripts/demo_n5_n4.py
"""

from __future__ import annotations

import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from ltm.agent import LTMAgent            # noqa: E402
from ltm.config import Config             # noqa: E402

SCENARIO = [
    ("phien-1", "Chào bạn, mình tên là Phong. Mình đang học tiếng Nhật, trình độ N5."),
    ("phien-1", "Mình bị dị ứng đậu phộng nhé."),
    ("phien-4", "Gợi ý cho mình vài tài liệu luyện đọc phù hợp trình độ."),
    ("phien-7", "Mình vừa thi đỗ N4 rồi!"),
    ("phien-9", "Giờ thì gợi ý tài liệu luyện đọc cho mình đi."),
]


def main() -> int:
    cfg = Config.load()
    cfg.store.persist_dir = tempfile.mkdtemp(prefix="ltm-demo-")
    agent = LTMAgent(cfg)
    agent.memory.reset()

    print(f"LLM provider: {cfg.llm.provider}\n" + "=" * 72)

    for session, msg in SCENARIO:
        turn = agent.chat(msg, session_id=session)
        print(f"\n[{session}] Người dùng: {msg}")
        print(f"          Trợ lý: {turn.reply}")
        if turn.retrieval.records:
            print("          ký ức dùng: "
                  + "; ".join(r.render() for r in turn.retrieval.records))
        for d in turn.ingest.decisions:
            print(f"          bộ nhớ  : {d.op.value} {d.slot} — {d.reason}")

    print("\n" + "=" * 72)
    print("KIỂM TRA CUỐI")
    current = agent.memory.current_value("trinh_do_tieng_nhat")
    print(f"  Trình độ tiếng Nhật hiện tại: {current}")
    print("  Lịch sử slot:")
    for r in agent.memory.history("trinh_do_tieng_nhat"):
        mark = "  ← đang có hiệu lực" if r.status.value == "active" else ""
        print(f"    #{r.seq}  {r.value:<6} {r.status.value}{mark}")
    print(f"  Thống kê kho: {agent.memory.stats()}")

    ok = current == "N4"
    print("\n  KẾT QUẢ:", "ĐẠT — bộ nhớ đã cập nhật N5 -> N4" if ok
          else f"KHÔNG ĐẠT — vẫn đang là {current}")

    if cfg.llm.provider == "mock":
        print(
            "\n  LƯU Ý: đang chạy embedding giả lập (hash trigram) nên phần TRUY XUẤT\n"
            "  theo ngữ nghĩa rất yếu — câu 'gợi ý tài liệu luyện đọc' không khớp được\n"
            "  với 'trình độ tiếng Nhật N4'. Cơ chế CẬP NHẬT (phần đang kiểm chứng) là\n"
            "  thuần Python nên vẫn đúng. Chạy lại với OPENAI_API_KEY để đo truy xuất thật."
        )
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
