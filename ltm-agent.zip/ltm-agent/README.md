# ltm-agent — Bộ nhớ dài hạn cho AI Assistant / LLM Agent

Khung dự án tuần 2. Python + OpenAI API + ChromaDB.

## Cài đặt

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # điền OPENAI_API_KEY
```

## Chạy thử

```bash
# Demo kịch bản N5 -> N4 (offline, không cần API key)
LTM_LLM_PROVIDER=mock python scripts/demo_n5_n4.py

# Test (offline)
LTM_LLM_PROVIDER=mock python -m pytest tests/ -v

# Hội thoại thật
export PYTHONPATH=src
python -m ltm.cli chat
python -m ltm.cli show
python -m ltm.cli history trinh_do_tieng_nhat
```

## Kiến trúc

```
Giao diện (CLI)  ⇄  LTMAgent  ⇄  MemoryManager  ⇄  VectorStore (Chroma)
                                      │
                    ┌─────────────────┼─────────────────┐
              FactExtractor     MemoryUpdater     MemoryRetriever
               (pha 1)           (pha 2)            (pha 3)
```

| Thư mục | Vai trò |
|---|---|
| `src/ltm/schema.py` | `MemoryRecord` — slot `(subject, attribute) -> value` + `seq` |
| `src/ltm/llm/` | Adapter LLM (`openai`, `mock`) sau một interface chung |
| `src/ltm/store/` | Adapter kho vector (`chroma`) sau một interface chung |
| `src/ltm/memory/extractor.py` | Pha 1 — LLM rút fact từ lượt hội thoại |
| `src/ltm/memory/updater.py` | Pha 2 — quyết định ADD / UPDATE / DELETE / NOOP |
| `src/ltm/memory/retriever.py` | Pha 3 — truy xuất top-k, lọc bản cũ |
| `src/ltm/agent.py` | Pha 4 — chèn ký ức vào prompt, sinh phản hồi |

## Quyết định thiết kế then chốt

**Không giao cho LLM việc phán đoán fact nào mới hơn.**

Mỗi fact được lưu thành slot `(subject, attribute)` kèm số thứ tự đơn điệu `seq`.
Khi có fact mới trùng slot: bản cũ chuyển `status=superseded` (vẫn giữ để truy vết),
bản mới nhận `seq` lớn hơn. Câu hỏi "giá trị hiện tại là gì" trở thành `max(seq)` —
một phép tính Python tất định, không phụ thuộc model.

LLM chỉ làm hai việc cần ngữ nghĩa: (1) trích fact từ câu nói tự do, (2) ghép một
thuộc tính mới với slot đã tồn tại (qua embedding của tên thuộc tính).

Lý do: trên bộ FactConsolidation (MemoryAgentBench, ICLR 2026), các hệ để LLM tự
theo dõi độ mới đạt điểm rất thấp — Zep/Graphiti ~7%, HippoRAG-v2 ~54%, GPT-4o
full-context ~60% (Reddy & Challaram, arXiv:2606.01435, 2026).

Truy xuất có hai lớp chống trả về fact cũ: lọc `status=active` ngay ở truy vấn, và
gom top-k theo slot chỉ giữ bản `seq` lớn nhất — vì embedding của bản cũ và bản mới
gần như giống hệt nhau nên top-k rất dễ trả về cả hai.

## Trạng thái

- [x] Kiến trúc module, interface tách rời LLM và vector DB
- [x] Vòng lặp 4 pha chạy được đầu–cuối
- [x] ADD / UPDATE / DELETE / NOOP + lịch sử slot
- [x] Truy xuất lọc bản cũ
- [x] CLI, 8 test offline
- [ ] Tuần 3: đo p50/p95, token/truy vấn; chạy LongMemEval-S
- [ ] Tuần 4: bộ test tiếng Việt theo khuôn FactConsolidation
