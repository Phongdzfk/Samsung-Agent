"""Test vòng lặp bộ nhớ. Chạy offline với LLM giả lập, không cần API key.

    LTM_LLM_PROVIDER=mock python -m pytest tests/ -v
"""

from __future__ import annotations

import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from ltm.config import Config                 # noqa: E402
from ltm.llm.mock_client import MockLLMClient  # noqa: E402
from ltm.memory.manager import MemoryManager   # noqa: E402
from ltm.schema import MemoryOp, MemoryStatus  # noqa: E402
from ltm.store import build_store              # noqa: E402


@pytest.fixture()
def mem():
    cfg = Config.load()
    cfg.llm.provider = "mock"
    cfg.store.persist_dir = tempfile.mkdtemp(prefix="ltm-test-")
    llm = MockLLMClient()
    store = build_store(cfg.store)
    m = MemoryManager(llm, store, cfg)
    m.reset()
    return m


def ops(report):
    return [d.op for d in report.decisions]


def test_add_fact_moi(mem):
    r = mem.ingest("Mình đang học tiếng Nhật, trình độ N5.", "s1", 1)
    assert MemoryOp.ADD in ops(r)
    assert mem.current_value("trinh_do_tieng_nhat") == "N5"


def test_noop_khi_lap_lai_cung_gia_tri(mem):
    mem.ingest("Trình độ tiếng Nhật của mình là N5.", "s1", 1)
    r = mem.ingest("Nhắc lại, trình độ N5 nhé.", "s2", 2)
    assert ops(r) == [MemoryOp.NOOP]
    assert mem.stats()["active"] == 1


def test_update_n5_sang_n4(mem):
    """Đây là kịch bản mentor hỏi: N5 -> nhập N4 -> phải thành N4."""
    mem.ingest("Trình độ tiếng Nhật của mình là N5.", "s1", 1)
    r = mem.ingest("Mình vừa thi đỗ N4 rồi!", "s2", 2)

    assert ops(r) == [MemoryOp.UPDATE]
    assert mem.current_value("trinh_do_tieng_nhat") == "N4"

    hist = mem.history("trinh_do_tieng_nhat")
    assert [x.value for x in hist] == ["N5", "N4"]
    assert hist[0].status is MemoryStatus.SUPERSEDED
    assert hist[1].status is MemoryStatus.ACTIVE
    # bản mới phải có seq lớn hơn — đây là căn cứ xác định độ mới
    assert hist[1].seq > hist[0].seq
    assert hist[0].superseded_by == hist[1].id


def test_chuoi_cap_nhat_nhieu_buoc(mem):
    """N5 -> N4 -> N3: luôn phải trả về bản cuối cùng."""
    for lv, turn in (("N5", 1), ("N4", 2), ("N3", 3)):
        mem.ingest(f"Trình độ tiếng Nhật của mình là {lv}.", f"s{turn}", turn)
    assert mem.current_value("trinh_do_tieng_nhat") == "N3"
    assert len(mem.history("trinh_do_tieng_nhat")) == 3
    assert mem.stats()["superseded"] == 2


def test_delete_khi_phu_dinh(mem):
    mem.ingest("Mình bị dị ứng đậu phộng.", "s1", 1)
    assert mem.current_value("di_ung") is not None
    r = mem.ingest("Mình hết dị ứng đậu phộng rồi.", "s2", 2)
    assert MemoryOp.DELETE in ops(r)
    assert mem.current_value("di_ung") is None


def test_truy_xuat_khong_tra_ve_ban_cu(mem):
    """Bản bị thay thế không được lọt vào kết quả truy xuất."""
    mem.ingest("Trình độ tiếng Nhật của mình là N5.", "s1", 1)
    mem.ingest("Mình vừa thi đỗ N4 rồi!", "s2", 2)

    res = mem.recall("trình độ tiếng Nhật của tôi", k=5)
    values = [r.value for r in res.records]
    assert "N4" in values
    assert "N5" not in values


def test_bo_nho_ton_tai_xuyen_phien(mem):
    mem.ingest("Mình tên là Phong.", "phien-1", 1)
    mem.ingest("Trình độ tiếng Nhật của mình là N5.", "phien-1", 2)
    # nhiều phiên sau
    mem.ingest("Mình vừa thi đỗ N4 rồi!", "phien-12", 30)
    assert mem.current_value("ten") == "Phong"
    assert mem.current_value("trinh_do_tieng_nhat") == "N4"


def test_seq_don_dieu(mem):
    mem.ingest("Mình tên là Phong.", "s1", 1)
    mem.ingest("Trình độ tiếng Nhật của mình là N5.", "s1", 2)
    mem.ingest("Mình vừa thi đỗ N4 rồi!", "s2", 3)
    seqs = [r.seq for r in mem.store.all_records()]
    assert seqs == sorted(seqs)
    assert len(set(seqs)) == len(seqs)  # không trùng
