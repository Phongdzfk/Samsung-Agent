"""Lược đồ bản ghi bộ nhớ.

Điểm thiết kế cốt lõi: mỗi fact được lưu dưới dạng SLOT (subject, attribute) -> value,
kèm một số thứ tự đơn điệu `seq`. Nhờ đó việc "fact nào mới nhất" được quyết định bằng
max(seq) — một phép tính xác định — thay vì hỏi LLM.

Cơ sở: Reddy & Challaram, "Don't Ask the LLM to Track Freshness: A Deterministic Recipe
for Memory Conflict Resolution", arXiv:2606.01435 (2026). Trên FactConsolidation
(MemoryAgentBench, ICLR 2026), các hệ để LLM tự phán đoán độ mới đạt điểm rất thấp
(Zep/Graphiti ~7%, HippoRAG-v2 ~54%).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MemoryType(str, Enum):
    SEMANTIC = "semantic"    # sự thật / sở thích bền vững về người dùng
    EPISODIC = "episodic"    # sự kiện đã xảy ra, gắn mốc thời gian
    PROCEDURAL = "procedural"  # chỉ dẫn / luật hành xử (mở rộng)


class MemoryStatus(str, Enum):
    ACTIVE = "active"          # bản ghi đang có hiệu lực
    SUPERSEDED = "superseded"  # đã bị bản mới hơn thay thế (giữ lại để truy vết)
    DELETED = "deleted"        # bị người dùng phủ định / yêu cầu xóa


class MemoryOp(str, Enum):
    ADD = "ADD"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    NOOP = "NOOP"


@dataclass
class MemoryRecord:
    """Một đơn vị ký ức."""

    subject: str          # thực thể sở hữu fact, vd "user"
    attribute: str        # khóa slot đã chuẩn hóa, vd "trinh_do_tieng_nhat"
    value: str            # giá trị hiện tại, vd "N4"
    text: str             # câu tự nhiên dùng để nhúng embedding

    seq: int = 0          # số thứ tự đơn điệu toàn cục -> nguồn sự thật về độ mới
    memory_type: MemoryType = MemoryType.SEMANTIC
    status: MemoryStatus = MemoryStatus.ACTIVE

    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    session_id: str = ""
    turn_id: int = -1

    created_at: str = field(default_factory=_now)
    valid_from: str = field(default_factory=_now)
    invalidated_at: Optional[str] = None
    superseded_by: Optional[str] = None

    confidence: float = 1.0
    source_text: str = ""   # lượt hội thoại gốc, để truy vết

    # ---- tiện ích ----

    @property
    def slot(self) -> str:
        return f"{self.subject}::{self.attribute}"

    def to_metadata(self) -> dict[str, Any]:
        """Chroma chỉ nhận metadata kiểu str/int/float/bool nên phải làm phẳng."""
        d = asdict(self)
        d.pop("text")
        d["memory_type"] = self.memory_type.value
        d["status"] = self.status.value
        d["slot"] = self.slot
        return {k: ("" if v is None else v) for k, v in d.items()}

    @classmethod
    def from_metadata(cls, meta: dict[str, Any], text: str) -> "MemoryRecord":
        meta = dict(meta)
        meta.pop("slot", None)
        for k in ("invalidated_at", "superseded_by"):
            if meta.get(k) == "":
                meta[k] = None
        meta["memory_type"] = MemoryType(meta["memory_type"])
        meta["status"] = MemoryStatus(meta["status"])
        return cls(text=text, **meta)

    def render(self) -> str:
        return f"[#{self.seq}] {self.text}"
