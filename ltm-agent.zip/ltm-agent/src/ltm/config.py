"""Cấu hình tập trung — mọi tham số thí nghiệm nằm ở một chỗ.

Nguyên tắc đánh giá: khi so sánh các cấu hình bộ nhớ, phải cố định cùng LLM,
cùng k, cùng ngân sách token. Gom hết vào đây để mỗi lần chạy chỉ đổi một biến.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class LLMConfig:
    provider: str = os.getenv("LTM_LLM_PROVIDER", "openai")  # openai | mock
    model: str = os.getenv("LTM_LLM_MODEL", "gpt-4o-mini")
    embedding_model: str = os.getenv("LTM_EMBEDDING_MODEL", "text-embedding-3-small")
    temperature: float = 0.0        # 0 để kết quả lặp lại được
    max_output_tokens: int = 1024
    api_key: str | None = field(default_factory=lambda: os.getenv("OPENAI_API_KEY"))


@dataclass
class StoreConfig:
    provider: str = os.getenv("LTM_STORE_PROVIDER", "chroma")
    persist_dir: str = os.getenv("LTM_PERSIST_DIR", "./data/chroma")
    collection: str = "ltm_memories"


@dataclass
class RetrievalConfig:
    top_k: int = 5              # k ký ức lấy ra
    threshold: float = 0.25     # ngưỡng tương đồng cosine tối thiểu
    slot_match_threshold: float = 0.82  # ngưỡng coi 2 slot là cùng một thuộc tính
    max_context_tokens: int = 1200      # ngân sách token cho phần ký ức trong prompt


@dataclass
class Config:
    llm: LLMConfig = field(default_factory=LLMConfig)
    store: StoreConfig = field(default_factory=StoreConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)

    @classmethod
    def load(cls) -> "Config":
        return cls()
