"""Giao diện trừu tượng cho kho vector — đổi Chroma sang Qdrant/FAISS không sửa code lõi."""

from __future__ import annotations

import abc

from ..schema import MemoryRecord


class VectorStore(abc.ABC):
    @abc.abstractmethod
    def upsert(self, records: list[MemoryRecord], embeddings: list[list[float]]) -> None: ...

    @abc.abstractmethod
    def search(
        self, embedding: list[float], k: int, where: dict | None = None
    ) -> list[tuple[MemoryRecord, float]]:
        """Trả về [(bản ghi, độ tương đồng cosine)] đã sắp giảm dần."""

    @abc.abstractmethod
    def get_by_slot(self, slot: str, active_only: bool = True) -> list[MemoryRecord]: ...

    @abc.abstractmethod
    def update_metadata(self, record_id: str, patch: dict) -> None: ...

    @abc.abstractmethod
    def all_records(self, active_only: bool = False) -> list[MemoryRecord]: ...

    @abc.abstractmethod
    def count(self) -> int: ...

    @abc.abstractmethod
    def reset(self) -> None: ...
