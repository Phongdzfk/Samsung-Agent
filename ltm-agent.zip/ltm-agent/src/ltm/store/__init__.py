from ..config import StoreConfig
from .base import VectorStore


def build_store(cfg: StoreConfig) -> VectorStore:
    if cfg.provider == "chroma":
        from .chroma_store import ChromaStore

        return ChromaStore(cfg)
    raise ValueError(f"Chưa hỗ trợ store: {cfg.provider}")


__all__ = ["VectorStore", "build_store"]
