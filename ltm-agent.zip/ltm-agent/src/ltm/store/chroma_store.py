"""Kho vector dùng ChromaDB (persist ra đĩa)."""

from __future__ import annotations

from ..config import StoreConfig
from ..schema import MemoryRecord, MemoryStatus
from .base import VectorStore


class ChromaStore(VectorStore):
    def __init__(self, cfg: StoreConfig):
        import chromadb

        self.cfg = cfg
        self.client = chromadb.PersistentClient(path=cfg.persist_dir)
        self.col = self.client.get_or_create_collection(
            name=cfg.collection,
            metadata={"hnsw:space": "cosine"},
        )

    # ---- ghi ----

    def upsert(self, records: list[MemoryRecord], embeddings: list[list[float]]) -> None:
        if not records:
            return
        self.col.upsert(
            ids=[r.id for r in records],
            embeddings=embeddings,
            documents=[r.text for r in records],
            metadatas=[r.to_metadata() for r in records],
        )

    def update_metadata(self, record_id: str, patch: dict) -> None:
        got = self.col.get(ids=[record_id], include=["metadatas"])
        if not got["ids"]:
            return
        meta = dict(got["metadatas"][0])
        meta.update({k: ("" if v is None else v) for k, v in patch.items()})
        self.col.update(ids=[record_id], metadatas=[meta])

    # ---- đọc ----

    def search(
        self, embedding: list[float], k: int, where: dict | None = None
    ) -> list[tuple[MemoryRecord, float]]:
        if self.count() == 0:
            return []
        res = self.col.query(
            query_embeddings=[embedding],
            n_results=min(k, self.count()),
            where=where,
            include=["metadatas", "documents", "distances"],
        )
        out: list[tuple[MemoryRecord, float]] = []
        for meta, doc, dist in zip(
            res["metadatas"][0], res["documents"][0], res["distances"][0]
        ):
            # Chroma trả cosine distance -> đổi về similarity
            out.append((MemoryRecord.from_metadata(meta, doc), 1.0 - float(dist)))
        return out

    def get_by_slot(self, slot: str, active_only: bool = True) -> list[MemoryRecord]:
        where: dict = {"slot": slot}
        if active_only:
            where = {"$and": [{"slot": slot}, {"status": MemoryStatus.ACTIVE.value}]}
        got = self.col.get(where=where, include=["metadatas", "documents"])
        recs = [
            MemoryRecord.from_metadata(m, d)
            for m, d in zip(got["metadatas"], got["documents"])
        ]
        return sorted(recs, key=lambda r: r.seq, reverse=True)

    def all_records(self, active_only: bool = False) -> list[MemoryRecord]:
        where = {"status": MemoryStatus.ACTIVE.value} if active_only else None
        got = self.col.get(where=where, include=["metadatas", "documents"])
        recs = [
            MemoryRecord.from_metadata(m, d)
            for m, d in zip(got["metadatas"], got["documents"])
        ]
        return sorted(recs, key=lambda r: r.seq)

    def count(self) -> int:
        return self.col.count()

    def reset(self) -> None:
        self.client.delete_collection(self.cfg.collection)
        self.col = self.client.get_or_create_collection(
            name=self.cfg.collection, metadata={"hnsw:space": "cosine"}
        )
