"""LLM Agent — điều phối: truy xuất ký ức -> sinh phản hồi -> ghi nhớ lượt vừa rồi."""

from __future__ import annotations

import time
from dataclasses import dataclass

from .config import Config
from .llm import build_llm
from .llm.base import LLMClient
from .memory.manager import IngestReport, MemoryManager
from .memory.retriever import RetrievalResult
from .store import build_store

SYSTEM = """Bạn là trợ lý có bộ nhớ dài hạn. SINH PHẢN HỒI dựa trên ký ức được cung cấp.

Quy tắc:
1. Ký ức đã cho là thông tin MỚI NHẤT đã được hệ thống xác thực. Hãy tin và dùng nó.
2. Nếu ký ức không chứa thông tin cần thiết, nói thẳng là bạn chưa biết. KHÔNG bịa.
3. Không hỏi lại điều đã có trong ký ức.
4. Trả lời bằng tiếng Việt, ngắn gọn.
"""


@dataclass
class Turn:
    user: str
    reply: str
    retrieval: RetrievalResult
    ingest: IngestReport
    latency_retrieval_ms: float
    latency_total_ms: float


class LTMAgent:
    def __init__(self, cfg: Config | None = None, llm: LLMClient | None = None):
        self.cfg = cfg or Config.load()
        self.llm = llm or build_llm(self.cfg.llm)
        self.store = build_store(self.cfg.store)
        self.memory = MemoryManager(self.llm, self.store, self.cfg)
        self.turn_id = 0

    def chat(self, user_message: str, session_id: str = "default") -> Turn:
        t0 = time.perf_counter()

        # 3. Truy xuất
        retrieval = self.memory.recall(user_message)
        t_retrieval = (time.perf_counter() - t0) * 1000

        # 4. Sinh phản hồi
        prompt = (
            f"KÝ ỨC LIÊN QUAN:\n{retrieval.render()}\n\n"
            f"CÂU HỎI HIỆN TẠI:\n{user_message}"
        )
        reply = self.llm.chat(SYSTEM, prompt)

        # 1 + 2. Trích xuất & cập nhật (làm sau khi trả lời để không tăng độ trễ cảm nhận)
        self.turn_id += 1
        ingest = self.memory.ingest(user_message, session_id, self.turn_id)

        return Turn(
            user=user_message,
            reply=reply,
            retrieval=retrieval,
            ingest=ingest,
            latency_retrieval_ms=t_retrieval,
            latency_total_ms=(time.perf_counter() - t0) * 1000,
        )
