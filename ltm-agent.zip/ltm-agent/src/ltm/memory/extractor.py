"""Pha 1 của vòng lặp bộ nhớ: TRÍCH XUẤT fact từ một lượt hội thoại.

LLM chỉ làm một việc duy nhất ở đây: biến câu nói tự do thành slot
(subject, attribute, value). LLM KHÔNG được giao việc phán đoán fact nào mới hơn —
việc đó do `updater.py` xử lý bằng số thứ tự, theo arXiv:2606.01435.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..llm.base import LLMClient
from ..schema import MemoryType

SYSTEM = """Bạn là bộ TRÍCH XUẤT thông tin cho hệ thống bộ nhớ dài hạn.

Nhiệm vụ: đọc một lượt hội thoại và rút ra các FACT bền vững về người dùng.

Quy tắc:
1. Chỉ rút thông tin có giá trị lâu dài (sở thích, thuộc tính, ràng buộc, mục tiêu).
   Bỏ qua lời chào, câu hỏi thuần túy, thông tin chỉ đúng trong chốc lát.
2. Mỗi fact là một cặp thuộc tính - giá trị. `attribute` phải là khóa không dấu,
   viết thường, nối bằng gạch dưới, ổn định giữa các lần gọi.
   Ví dụ: trinh_do_tieng_nhat, di_ung, noi_o, nghe_nghiep, muc_tieu_hoc_tap.
3. `text` là một câu tiếng Việt hoàn chỉnh, tự đứng độc lập được.
4. Nếu người dùng PHỦ ĐỊNH hoặc yêu cầu quên một thông tin, đặt "negated": true.
5. KHÔNG suy diễn. Chỉ ghi những gì người dùng nói ra.
6. Không có fact nào thì trả về [].

Định dạng đầu ra — một mảng JSON:
[{"subject":"user","attribute":"...","value":"...","text":"...",
  "memory_type":"semantic|episodic","negated":false}]
"""


@dataclass
class ExtractedFact:
    subject: str
    attribute: str
    value: str
    text: str
    memory_type: MemoryType = MemoryType.SEMANTIC
    negated: bool = False


class FactExtractor:
    def __init__(self, llm: LLMClient):
        self.llm = llm

    def extract(self, utterance: str, role: str = "user") -> list[ExtractedFact]:
        payload = f"Lượt hội thoại ({role}):\n{utterance}"
        raw = self.llm.chat_json(SYSTEM, payload)
        if not isinstance(raw, list):
            return []

        facts: list[ExtractedFact] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            attribute = str(item.get("attribute", "")).strip()
            value = str(item.get("value", "")).strip()
            if not attribute or not value:
                continue
            try:
                mtype = MemoryType(item.get("memory_type", "semantic"))
            except ValueError:
                mtype = MemoryType.SEMANTIC
            facts.append(
                ExtractedFact(
                    subject=str(item.get("subject", "user")).strip() or "user",
                    attribute=attribute,
                    value=value,
                    text=str(item.get("text", "")).strip() or f"{attribute}: {value}",
                    memory_type=mtype,
                    negated=bool(item.get("negated", False)),
                )
            )
        return facts
