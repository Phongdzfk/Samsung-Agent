"""Pha 3 của vòng lặp bộ nhớ: TRUY XUẤT ký ức liên quan tới câu hỏi hiện tại.

Hai lớp bảo vệ chống trả về fact cũ:
  1. Chỉ tìm trong bản ghi status = active (bản bị thay thế đã bị loại từ đầu).
  2. Sau khi có top-k, gom theo slot và chỉ giữ bản có seq lớn nhất mỗi slot.
Lớp 2 là cần thiết vì embedding của bản cũ và bản mới rất giống nhau, top-k dễ trả
về cả hai và làm LLM bối rối — đây chính là kiểu lỗi mà FactConsolidation nhắm vào.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..config import RetrievalConfig
from ..llm.base import LLMClient
from ..schema import MemoryRecord, MemoryStatus
from ..store.base import VectorStore


@dataclass
class RetrievalResult:
    records: list[MemoryRecord]
    scores: list[float]
    n_candidates: int
    n_dropped_stale: int

    def render(self) -> str:
        if not self.records:
            return "(không có)"
        return "\n".join(r.render() for r in self.records)


class MemoryRetriever:
    def __init__(self, llm: LLMClient, store: VectorStore, cfg: RetrievalConfig):
        self.llm = llm
        self.store = store
        self.cfg = cfg

    def retrieve(self, query: str, k: int | None = None) -> RetrievalResult:
        k = k or self.cfg.top_k
        if self.store.count() == 0:
            return RetrievalResult([], [], 0, 0)

        qv = self.llm.embed([query])[0]
        # lấy dư rồi mới lọc, tránh việc lọc xong không còn đủ k
        hits = self.store.search(
            qv, k=k * 3, where={"status": MemoryStatus.ACTIVE.value}
        )
        n_candidates = len(hits)

        hits = [(r, s) for r, s in hits if s >= self.cfg.threshold]

        # giữ bản mới nhất mỗi slot
        best_per_slot: dict[str, tuple[MemoryRecord, float]] = {}
        for rec, score in hits:
            prev = best_per_slot.get(rec.slot)
            if prev is None or rec.seq > prev[0].seq:
                best_per_slot[rec.slot] = (rec, score)
        n_dropped = len(hits) - len(best_per_slot)

        ranked = sorted(best_per_slot.values(), key=lambda x: x[1], reverse=True)[:k]
        return RetrievalResult(
            records=[r for r, _ in ranked],
            scores=[s for _, s in ranked],
            n_candidates=n_candidates,
            n_dropped_stale=n_dropped,
        )
