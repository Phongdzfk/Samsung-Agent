"""Bộ quản lý bộ nhớ — gói 4 pha của vòng lặp thành một giao diện duy nhất."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..config import Config
from ..llm.base import LLMClient
from ..schema import MemoryOp, MemoryRecord
from ..store.base import VectorStore
from .extractor import FactExtractor
from .retriever import MemoryRetriever, RetrievalResult
from .updater import MemoryUpdater, UpdateDecision


@dataclass
class IngestReport:
    """Nhật ký một lượt ghi nhớ — dùng cho phần đánh giá tính nhất quán."""

    decisions: list[UpdateDecision] = field(default_factory=list)

    def counts(self) -> dict[str, int]:
        out = {op.value: 0 for op in MemoryOp}
        for d in self.decisions:
            out[d.op.value] += 1
        return out

    def summary(self) -> str:
        if not self.decisions:
            return "Không trích được fact nào."
        return " | ".join(f"{d.op.value} {d.slot}: {d.reason}" for d in self.decisions)


class MemoryManager:
    def __init__(self, llm: LLMClient, store: VectorStore, cfg: Config):
        self.llm = llm
        self.store = store
        self.cfg = cfg
        self.extractor = FactExtractor(llm)
        self.updater = MemoryUpdater(llm, store, cfg.retrieval)
        self.retriever = MemoryRetriever(llm, store, cfg.retrieval)

    # --- pha 1 + 2 ---
    def ingest(self, utterance: str, session_id: str, turn_id: int) -> IngestReport:
        facts = self.extractor.extract(utterance)
        decisions = self.updater.process(facts, session_id, turn_id)
        return IngestReport(decisions=decisions)

    # --- pha 3 ---
    def recall(self, query: str, k: int | None = None) -> RetrievalResult:
        return self.retriever.retrieve(query, k)

    # --- tra cứu xác định ---
    def current_value(self, attribute: str, subject: str = "user") -> str | None:
        return self.updater.current_value(subject, attribute)

    def history(self, attribute: str, subject: str = "user") -> list[MemoryRecord]:
        return self.updater.history(subject, attribute)

    def stats(self) -> dict[str, int]:
        allr = self.store.all_records()
        return {
            "total": len(allr),
            "active": sum(1 for r in allr if r.status.value == "active"),
            "superseded": sum(1 for r in allr if r.status.value == "superseded"),
            "deleted": sum(1 for r in allr if r.status.value == "deleted"),
        }

    def reset(self) -> None:
        self.store.reset()
        self.updater._seq = 0
