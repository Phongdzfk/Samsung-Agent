"""Pha 2 của vòng lặp bộ nhớ: QUYẾT ĐỊNH ADD / UPDATE / DELETE / NOOP.

ĐÂY LÀ ĐÓNG GÓP CHÍNH CỦA ĐỒ ÁN.

Vấn đề: các hệ thống hiện có giao cho LLM việc phán đoán "fact nào mới hơn". Trên bộ
FactConsolidation (MemoryAgentBench, ICLR 2026) cách làm đó hỏng nặng:
Zep/Graphiti ~7%, HippoRAG-v2 ~54%, GPT-4o full-context ~60%.

Cách làm ở đây tách đôi trách nhiệm:
  - LLM chỉ GHÉP CẶP ngữ nghĩa (fact mới này nói về thuộc tính nào đã có?)
  - Python quyết định ĐỘ MỚI bằng max(seq) — tất định, không phụ thuộc model.

Tham chiếu: Reddy & Challaram, arXiv:2606.01435 (2026); Chhikara et al., Mem0, ECAI 2025
(khung thao tác ADD/UPDATE/DELETE/NOOP).
"""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass
from datetime import datetime, timezone

from ..config import RetrievalConfig
from ..llm.base import LLMClient
from ..schema import MemoryOp, MemoryRecord, MemoryStatus
from ..store.base import VectorStore
from .extractor import ExtractedFact


def _normalize(value: str) -> str:
    """Chuẩn hóa để so sánh giá trị: bỏ dấu, thường hóa, gọn khoảng trắng."""
    s = unicodedata.normalize("NFD", value.lower().strip())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return " ".join(s.split())


def _cosine(a: list[float], b: list[float]) -> float:
    num = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(y * y for y in b) ** 0.5
    return num / (na * nb) if na and nb else 0.0


@dataclass
class UpdateDecision:
    op: MemoryOp
    fact: ExtractedFact
    slot: str
    new_record: MemoryRecord | None = None
    superseded_id: str | None = None
    reason: str = ""


class MemoryUpdater:
    def __init__(self, llm: LLMClient, store: VectorStore, cfg: RetrievalConfig):
        self.llm = llm
        self.store = store
        self.cfg = cfg
        self._seq = self._load_max_seq()

    # ---- bộ đếm đơn điệu: nguồn sự thật duy nhất về độ mới ----

    def _load_max_seq(self) -> int:
        recs = self.store.all_records(active_only=False)
        return max((r.seq for r in recs), default=0)

    def _next_seq(self) -> int:
        self._seq += 1
        return self._seq

    # ---- ghép cặp slot (phần duy nhất cần ngữ nghĩa) ----

    def _resolve_slot(self, fact: ExtractedFact) -> str:
        """Tìm slot đã tồn tại mô tả cùng thuộc tính; nếu không có thì tạo slot mới.

        Ghép theo embedding của chính tên thuộc tính, KHÔNG hỏi LLM cái nào mới hơn.
        """
        exact = f"{fact.subject}::{fact.attribute}"
        if self.store.get_by_slot(exact, active_only=True):
            return exact

        existing = {r.slot: r for r in self.store.all_records(active_only=True)
                    if r.subject == fact.subject}
        if not existing:
            return exact

        slots = list(existing.keys())
        probe = f"{fact.subject} {fact.attribute.replace('_', ' ')}"
        texts = [probe] + [s.split("::", 1)[1].replace("_", " ") for s in slots]
        vecs = self.llm.embed(texts)
        qv, cand = vecs[0], vecs[1:]

        best_i, best_sim = -1, 0.0
        for i, v in enumerate(cand):
            sim = _cosine(qv, v)
            if sim > best_sim:
                best_i, best_sim = i, sim
        if best_i >= 0 and best_sim >= self.cfg.slot_match_threshold:
            return slots[best_i]
        return exact

    # ---- quyết định thao tác ----

    def decide(self, fact: ExtractedFact, session_id: str, turn_id: int) -> UpdateDecision:
        slot = self._resolve_slot(fact)
        active = self.store.get_by_slot(slot, active_only=True)
        current = active[0] if active else None  # max(seq) nhờ get_by_slot đã sắp xếp

        if fact.negated:
            if current is None:
                return UpdateDecision(MemoryOp.NOOP, fact, slot,
                                      reason="Phủ định nhưng chưa có gì để xóa.")
            return UpdateDecision(MemoryOp.DELETE, fact, slot, superseded_id=current.id,
                                  reason="Người dùng phủ định thông tin đã lưu.")

        subject, attribute = slot.split("::", 1)
        new = MemoryRecord(
            subject=subject,
            attribute=attribute,
            value=fact.value,
            text=fact.text,
            seq=0,  # gán ở apply()
            memory_type=fact.memory_type,
            session_id=session_id,
            turn_id=turn_id,
        )

        if current is None:
            return UpdateDecision(MemoryOp.ADD, fact, slot, new_record=new,
                                  reason="Slot chưa tồn tại.")
        if _normalize(current.value) == _normalize(fact.value):
            return UpdateDecision(MemoryOp.NOOP, fact, slot,
                                  reason=f"Giá trị không đổi ({current.value}).")
        return UpdateDecision(
            MemoryOp.UPDATE, fact, slot, new_record=new, superseded_id=current.id,
            reason=f"Giá trị đổi: {current.value} -> {fact.value}.",
        )

    # ---- thi hành ----

    def apply(self, decision: UpdateDecision) -> UpdateDecision:
        now = datetime.now(timezone.utc).isoformat()

        if decision.op is MemoryOp.NOOP:
            return decision

        if decision.op is MemoryOp.DELETE:
            self.store.update_metadata(
                decision.superseded_id,
                {"status": MemoryStatus.DELETED.value, "invalidated_at": now},
            )
            return decision

        rec = decision.new_record
        rec.seq = self._next_seq()
        rec.valid_from = now
        emb = self.llm.embed([rec.text])[0]
        self.store.upsert([rec], [emb])

        if decision.op is MemoryOp.UPDATE:
            # Bản cũ KHÔNG bị xóa: chuyển sang superseded để còn truy vết lịch sử.
            self.store.update_metadata(
                decision.superseded_id,
                {
                    "status": MemoryStatus.SUPERSEDED.value,
                    "invalidated_at": now,
                    "superseded_by": rec.id,
                },
            )
        return decision

    def process(self, facts: list[ExtractedFact], session_id: str, turn_id: int
                ) -> list[UpdateDecision]:
        return [self.apply(self.decide(f, session_id, turn_id)) for f in facts]

    # ---- truy vấn độ mới: thuần Python, không gọi LLM ----

    def current_value(self, subject: str, attribute: str) -> str | None:
        recs = self.store.get_by_slot(f"{subject}::{attribute}", active_only=True)
        return max(recs, key=lambda r: r.seq).value if recs else None

    def history(self, subject: str, attribute: str) -> list[MemoryRecord]:
        recs = self.store.get_by_slot(f"{subject}::{attribute}", active_only=False)
        return sorted(recs, key=lambda r: r.seq)
