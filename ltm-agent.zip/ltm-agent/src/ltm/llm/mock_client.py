"""LLM giả lập — chạy offline, không tốn tiền, kết quả tất định.

Mục đích: (1) chạy unit test và CI mà không cần API key; (2) làm baseline "no-LLM"
để tách bạch phần nào của kết quả đến từ LLM, phần nào đến từ cơ chế bộ nhớ.
Đây KHÔNG phải mô hình thật — chỉ nhận diện vài mẫu câu tiếng Việt cho demo.
"""

from __future__ import annotations

import hashlib
import json
import math
import re

from .base import LLMClient

# Các mẫu trích xuất fact dùng cho demo. Thực tế phần này do LLM đảm nhiệm.
_PATTERNS: list[tuple[str, str, str]] = [
    # (regex, attribute, template câu tự nhiên)
    (r"(?:trình độ|level|lên|đạt|thi đỗ|đỗ|pass)[^\n]{0,30}?\b(N[1-5])\b",
     "trinh_do_tieng_nhat", "Người dùng có trình độ tiếng Nhật {value}."),
    (r"dị ứng\s+(.+?)(?:[.,!\n]|$)", "di_ung",
     "Người dùng bị dị ứng {value}."),
    (r"(?:tôi|mình)[^\n]{0,12}?(?:sống|ở)\s+(?:tại\s+)?([A-ZĐÀ-Ỹ][\w\sÀ-ỹ]{1,25}?)(?:[.,!\n]|$)",
     "noi_o", "Người dùng đang sống ở {value}."),
    (r"(?:tôi|mình)\s*(?:tên là|tên)\s+([A-ZĐÀ-Ỹ][\w\sÀ-ỹ]{1,25}?)(?:[.,!\n]|$)",
     "ten", "Tên người dùng là {value}."),
]

_NEGATION = re.compile(
    r"(không còn|đừng nhớ|bỏ đi|hủy|quên|không học|hết dị ứng|khỏi dị ứng)", re.I
)

# tiểu từ cuối câu tiếng Việt cần cắt khỏi giá trị trích được
_TRAILING = re.compile(r"\s+(rồi|nhé|nha|nhá|nữa|ạ|đó|đấy|luôn|mà)\s*$", re.I)


def _fake_embedding(text: str, dim: int = 256) -> list[float]:
    """Embedding tất định dựa trên bag-of-trigram + hash. Đủ dùng cho test."""
    vec = [0.0] * dim
    t = re.sub(r"\s+", " ", text.lower().strip())
    grams = [t[i : i + 3] for i in range(max(len(t) - 2, 1))] or [t]
    for g in grams:
        h = int(hashlib.md5(g.encode()).hexdigest(), 16)
        vec[h % dim] += 1.0
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


class MockLLMClient(LLMClient):
    def __init__(self, *_args, **_kwargs):
        self.n_calls = 0

    def chat(self, system: str, user: str) -> str:
        self.n_calls += 1
        if "TRÍCH XUẤT" in system.upper():
            return json.dumps(self._extract(user), ensure_ascii=False)
        if "SINH PHẢN HỒI" in system.upper():
            return self._respond(user)
        return ""

    def embed(self, texts: list[str]) -> list[list[float]]:
        return [_fake_embedding(t) for t in texts]

    # ---- nội bộ ----

    def _extract(self, text: str) -> list[dict]:
        facts: list[dict] = []
        negated = bool(_NEGATION.search(text))
        for pattern, attribute, template in _PATTERNS:
            m = re.search(pattern, text, re.I)
            if not m:
                continue
            value = m.group(1).strip().rstrip(".")
            while True:
                stripped = _TRAILING.sub("", value).strip()
                if stripped == value:
                    break
                value = stripped
            if not value:
                continue
            if attribute == "trinh_do_tieng_nhat":
                value = value.upper()
            facts.append(
                {
                    "subject": "user",
                    "attribute": attribute,
                    "value": value,
                    "text": template.format(value=value),
                    "memory_type": "semantic",
                    "negated": negated,
                }
            )
        return facts

    def _respond(self, user: str) -> str:
        m = re.search(r"KÝ ỨC LIÊN QUAN:\n(.*?)\n\nCÂU HỎI", user, re.S)
        memories = m.group(1).strip() if m else ""
        if not memories or memories == "(không có)":
            return "Tôi chưa có thông tin về việc này."
        return "Dựa trên những gì tôi đã ghi nhớ: " + " ".join(
            line.split("] ", 1)[-1] for line in memories.splitlines() if line.strip()
        )

    def stats(self) -> dict[str, int]:
        return {"n_calls": self.n_calls, "total_tokens": 0}
