from ..config import LLMConfig
from .base import LLMClient
from .mock_client import MockLLMClient


def build_llm(cfg: LLMConfig) -> LLMClient:
    """Factory — đổi provider chỉ bằng biến môi trường LTM_LLM_PROVIDER."""
    if cfg.provider == "mock":
        return MockLLMClient()
    if cfg.provider == "openai":
        from .openai_client import OpenAIClient

        return OpenAIClient(cfg)
    raise ValueError(f"Chưa hỗ trợ provider: {cfg.provider}")


__all__ = ["LLMClient", "MockLLMClient", "build_llm"]
