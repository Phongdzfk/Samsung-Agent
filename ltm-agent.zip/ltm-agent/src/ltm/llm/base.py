"""Giao diện trừu tượng cho LLM — đổi nhà cung cấp không phải sửa code lõi."""

from __future__ import annotations

import abc
import json
import re
from typing import Any


class LLMClient(abc.ABC):
    """Mọi client phải cung cấp 3 năng lực: chat, chat có JSON, và embedding."""

    @abc.abstractmethod
    def chat(self, system: str, user: str) -> str: ...

    @abc.abstractmethod
    def embed(self, texts: list[str]) -> list[list[float]]: ...

    def chat_json(self, system: str, user: str) -> Any:
        """Gọi chat rồi ép về JSON. Có vá lỗi khi model bọc trong ```json."""
        raw = self.chat(system + "\n\nCHỈ trả về JSON hợp lệ, không giải thích thêm.", user)
        return parse_json_loose(raw)


def parse_json_loose(raw: str) -> Any:
    """Bóc JSON ra khỏi văn bản model trả về. Trả [] nếu thất bại."""
    raw = raw.strip()
    fence = re.search(r"```(?:json)?\s*(.+?)\s*```", raw, re.S)
    if fence:
        raw = fence.group(1)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass
    for opener, closer in (("[", "]"), ("{", "}")):
        i, j = raw.find(opener), raw.rfind(closer)
        if i != -1 and j > i:
            try:
                return json.loads(raw[i : j + 1])
            except json.JSONDecodeError:
                continue
    return []
