"""Adapter OpenAI. Có đếm token để phục vụ trục đo chi phí."""

from __future__ import annotations

from ..config import LLMConfig
from .base import LLMClient


class OpenAIClient(LLMClient):
    def __init__(self, cfg: LLMConfig):
        from openai import OpenAI

        if not cfg.api_key:
            raise RuntimeError(
                "Thiếu OPENAI_API_KEY. Đặt biến môi trường hoặc dùng provider=mock."
            )
        self.cfg = cfg
        self.client = OpenAI(api_key=cfg.api_key)
        # thống kê phục vụ đo chi phí
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.n_calls = 0

    def chat(self, system: str, user: str) -> str:
        resp = self.client.chat.completions.create(
            model=self.cfg.model,
            temperature=self.cfg.temperature,
            max_tokens=self.cfg.max_output_tokens,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        self.n_calls += 1
        if resp.usage:
            self.prompt_tokens += resp.usage.prompt_tokens
            self.completion_tokens += resp.usage.completion_tokens
        return (resp.choices[0].message.content or "").strip()

    def embed(self, texts: list[str]) -> list[list[float]]:
        resp = self.client.embeddings.create(
            model=self.cfg.embedding_model, input=texts
        )
        return [d.embedding for d in resp.data]

    def stats(self) -> dict[str, int]:
        return {
            "n_calls": self.n_calls,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.prompt_tokens + self.completion_tokens,
        }
