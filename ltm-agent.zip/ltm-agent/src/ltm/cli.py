"""Giao diện dòng lệnh tối thiểu — yêu cầu "giao diện tương tác" của tuần 2.

Dùng:
    python -m ltm.cli chat                 # hội thoại nhiều phiên
    python -m ltm.cli show                 # xem toàn bộ bộ nhớ
    python -m ltm.cli history <attribute>  # xem lịch sử một slot
    python -m ltm.cli reset
"""

from __future__ import annotations

import argparse
import sys

from .agent import LTMAgent
from .config import Config


def _print_turn(turn) -> None:
    print(f"\n\033[1mTrợ lý:\033[0m {turn.reply}")
    if turn.retrieval.records:
        print("\033[2m  ký ức đã dùng:\033[0m")
        for rec, score in zip(turn.retrieval.records, turn.retrieval.scores):
            print(f"\033[2m    · {rec.render()}  (sim={score:.3f})\033[0m")
    if turn.ingest.decisions:
        print("\033[2m  bộ nhớ:\033[0m")
        for d in turn.ingest.decisions:
            print(f"\033[2m    · {d.op.value:<6} {d.slot} — {d.reason}\033[0m")
    print(
        f"\033[2m  truy xuất {turn.latency_retrieval_ms:.0f}ms · "
        f"tổng {turn.latency_total_ms:.0f}ms\033[0m"
    )


def cmd_chat(agent: LTMAgent, args) -> None:
    print("Gõ /session <tên> để đổi phiên, /quit để thoát.\n")
    session = "phien-1"
    while True:
        try:
            line = input(f"\033[1m[{session}] Bạn:\033[0m ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line in ("/quit", "/exit"):
            break
        if line.startswith("/session "):
            session = line.split(" ", 1)[1].strip()
            print(f"→ Đã chuyển sang phiên '{session}'. Bộ nhớ dài hạn vẫn giữ nguyên.")
            continue
        _print_turn(agent.chat(line, session_id=session))


def cmd_show(agent: LTMAgent, args) -> None:
    records = agent.store.all_records()
    if not records:
        print("Bộ nhớ trống.")
        return
    print(f"{'SEQ':>4}  {'TRẠNG THÁI':<11} {'SLOT':<34} GIÁ TRỊ")
    print("-" * 78)
    for r in records:
        print(f"{r.seq:>4}  {r.status.value:<11} {r.slot:<34} {r.value}")
    print("\nThống kê:", agent.memory.stats())


def cmd_history(agent: LTMAgent, args) -> None:
    recs = agent.memory.history(args.attribute)
    if not recs:
        print(f"Không có bản ghi nào cho thuộc tính '{args.attribute}'.")
        return
    print(f"Lịch sử của '{args.attribute}':")
    for r in recs:
        mark = "← hiện tại" if r.status.value == "active" else ""
        print(f"  #{r.seq}  {r.value:<20} {r.status.value:<11} {r.valid_from[:19]} {mark}")


def cmd_reset(agent: LTMAgent, args) -> None:
    agent.memory.reset()
    print("Đã xóa sạch bộ nhớ.")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="ltm", description="Bộ nhớ dài hạn cho LLM Agent")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("chat").set_defaults(fn=cmd_chat)
    sub.add_parser("show").set_defaults(fn=cmd_show)
    h = sub.add_parser("history")
    h.add_argument("attribute")
    h.set_defaults(fn=cmd_history)
    sub.add_parser("reset").set_defaults(fn=cmd_reset)

    args = p.parse_args(argv)
    agent = LTMAgent(Config.load())
    args.fn(agent, args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
